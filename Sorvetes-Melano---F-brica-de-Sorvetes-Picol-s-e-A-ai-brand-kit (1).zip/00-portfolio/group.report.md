# Group benchmark — Sorvetes Melano - Fábrica de Sorvetes, Picolés e Açai

*1 businesses · generated 2026-11-03T16:04:52Z*

## Ranked overview

| Business | Rating | Reviews | Followers | Platforms | Overall | Reputation | Social | Content |
|---|---|---|---|---|---|---|---|---|
| Sorvetes Melano - Fábrica de Sorvetes, Picolés e Açai | 4.7 | 137 | 10,107 | 2 | 56.6 | 67.5 | 51.6 | 34.0 |

## Source coverage

| Source | Businesses with data |
|---|---|
| website | 1 |
| google | 1 |
| facebook | 1 |
| instagram | 1 |

## Cross-business gaps

**Sorvetes Melano - Fábrica de Sorvetes, Picolés e Açai**
- No owner responses visible on the collected reviews

