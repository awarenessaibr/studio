# Sorvetes Melano - Fábrica de Sorvetes, Picolés e Açai — social & reputation intelligence

*Generated 2026-11-03T16:04:52Z · group `Sorvetes Melano - Fábrica de Sorvetes, Picolés e Açai` · schema v2.0*

## 1. Snapshot

| Signal | Value |
|---|---|
| Consensus rating | 4.7 / 5 |
| Reviews across sources | 137 |
| Reviews analysed in detail | 15 |
| Sources present | google |
| Combined social followers | 10,107 |
| Platforms present | 2 of 2 |
| Last social activity | unknown |
| Online booking | no |
| Menu online | no |
| Overall score | 56.6 / 100 |

| Reputation | Social | Content | Discoverability |
|---|---|---|---|
| 67.5 | 51.6 | 34.0 | 66.2 |


## 2. Identity & NAP

| Field | Canonical value |
|---|---|
| Name | Sorvetes Melano - Fábrica de Sorvetes, Picolés e Açai |
| Address | R. Manoel da Rocha, 753 - St. Central, Gurupi - TO, 77402-040, Brazil |
| Phone | (63) 3312-2726 |
| Website | http://melano.com.br/ |
| Emails | atendimento@melano.com.br |

_No NAP conflicts detected across sources._

## 3. Reputation across platforms

| Platform | Rating | Reviews | Analysed | Mode |
|---|---|---|---|---|
| Google Maps | 4.7/5 | 137 | 20 | places-api+serpapi |

| Stars | Count |
|---|---|
| 5★ | 9 |
| 4★ | 1 |
| 2★ | 2 |
| 1★ | 3 |

- Latest review: **2026-10-31**
- Velocity: **1.36 reviews/month** across 11 months
- Trend: **improving** (4.38 recent vs 3.0 older)
- Owner response rate: **0%**
- Sentiment: **0% positive**, 0% negative (mean 0.0)

**Red flags**
- `medium` **low owner-response rate** — 0% of visible reviews have a reply

## 4. What guests talk about

_(no data)_

**Standout praise**
> Experiência excepcional!!
Sempre com prontidão em atender e com variedades em opções!
Sempre comprei para empresa. Muito satisfeita com o atendimento!
> — Kamilla Costa, 5.0★ 2026-06-26 (Google Maps)


## 5. Social presence

| Platform | Present | Followers | Posts | Last post | Mode |
|---|---|---|---|---|---|
| Instagram | yes | 8,713 | 735 | — | web-public |
| Facebook | yes | 1,394 | — | — | web-public |

- **Not discovered:** tiktok, youtube
- Handle consistency: **0.0**

## 6. Web & conversion path

| Signal | Value |
|---|---|
| Website | http://melano.com.br/ |
| Pages crawled | 11 |
| Sitemap URLs |  |
| Booking providers | — |
| Delivery providers | — |
| Menu online | no |
| Tech detected | — |


## 7. Signals

**Strengths**
- Strong consensus rating of 4.7/5 across 1 platforms
- 10,107 combined followers across 2 social platforms

**Weaknesses**
- No owner responses visible on the collected reviews

**Opportunities**
- Add online booking (OpenTable/ResDiary/SevenRooms) to capture direct demand
- No profile found on tiktok, youtube — seed UGC reposts and short-form video there
- Reply to every recent review — replies correlate with higher ratings and conversion
- Review volume is thin relative to competitors — a post-visit ask could double social proof
- No delivery presence detected — consider Deliveroo/Uber Eats for incremental revenue

**Risks**
- low owner-response rate: 0% of visible reviews have a reply

## 8. Provenance

| Source | Mode | URL | Rating | Count | Pulled | Warnings |
|---|---|---|---|---|---|---|
| food_hygiene | fsa-api | — | — | — | 0 | not a UK establishment |
| website | http | http://melano.com.br/ | — | — | 0 | — |
| press | web-search | https://www.bing.com/search?q=%22Sorvetes%20Melano%20-%20F%C3%A1brica%20de%20Sorvetes%2C%20Picol%C3%A9s%20e%20A%C3%A7ai%22%20gurupi | — | — | 0 | no independent web mentions found |
| google | places-api+serpapi | https://maps.google.com/?cid=3142177839918151995&g_mp=Cidnb29nbGUubWFwcy5wbGFjZXMudjEuUGxhY2VzLlNlYXJjaFRleHQQAhgEIAA | 4.7 | 137 | 20 | — |
| facebook | web-public | https://www.facebook.com/melanobr/ | — | — | 0 | — |
| instagram | web-public | https://www.instagram.com/sorvetesmelano/ | — | — | 0 | — |


_Searched, no profile URL discovered (1): restaurantguru. These are discovery gaps, not platform gaps._

