# Sorvetes Melano - Fábrica de Sorvetes, Picolés e Açai

Brand kit generated from a studio intake crawl for Sorvetes Melano - Fábrica de Sorvetes, Picolés e Açai.

## Brands

- 01-melano-com-br — Melano Sorvetes (http://melano.com.br/) · rating 4.7 from 137 reviews · 10,107 followers · score 56.6/100

## Contents

- `00-portfolio/` — portfolio overview (.docx / .json) and the cross-business benchmark (`group.report.md`, `group.summary.json`).
- `NN-<brand>/` — brand guide (.docx, `brand-guide.json`), `tokens/`, `content/`, `assets/`, and `social/` (reputation + social dossier: `insights.md`, `report.html`, `business.profile.json`, `reviews.csv`, ...).
- `targets.json` — the business records handed from the website crawl to the social crawl.
